<!DOCTYPE html>
<html lang="pt-	br">
<head>
<title>Curiosidades</title>
<meta charset="utf-8">
<link rel="stylesheet" href="F:\Mackenzie\Tecnologia WEB I\projeto-Oscar\css\estiloCuriosidades.css">
</head>
<body>
<div id="site">

<header id="topo">
inclue header.inc;
</header></br>

<nav id="menu">
include 'menu.inc';
</nav>

<section id="conteudo">
<article>
<p><h3>
 1º  Walt Disney é o grande vencedor do maior prêmio do cinema, tendo levado 26 estatuetas para casa. O cineasta também conseguiu o feito de ser indicado ao prêmio por 22 anos consecutivos.
</br></br>2º  A estrela mais jovem a conquistar o Oscar é a atriz Tatum O’Neal, que foi premiada como Melhor Atriz Coadjuvante no filme “Lua de Papel” (1973) quando tinha apenas dez anos.
</br></br>3º  Para poder concorrer ao Oscar de Melhor Filme do ano, a produção precisa cumprir algumas exigências: ter mais de 40 minutos de duração, ter sido exibida por pelo menos uma semana em Los Angeles e ter uma resolução de projeção de 2048x1080 pixels.
</br></br>4º  A produção mais longa da história a levar um Oscar é o clássico “Guerra e Paz” (1968), que foi premiado na categoria Melhor Filme Estrangeiro e tem mais de sete horas de duração.
</br></br>5º “Avatar” (2009) é o filme com maior orçamento da história a ganhar um Oscar. O valor total investido na produção não foi confirmado, mas estima-se que seja cerca de 230 milhões de dólares.
</br></br>6º  Na festa que ocorre após a premiação – que recebe o nome de Governors Ball –, são servidas 1,2 mil garrafas de champagne, mil lagostas, 1,2 mil ostras e 18 quilos de caviar.
</br></br>7º  O responsável pelas sobremesas servidas no baile usa 7 quilos de ouro comestível em pó para decorar as quatro mil miniaturas de estatuetas de chocolate que são oferecidas anualmente na festa.
</br></br>8º A primeira edição do Academy Awards – que somente recentemente ganhou o nome de The Oscars – aconteceu em 16 de maio de 1929.
</br></br>9º  Durante a Segunda Guerra Mundial, a falta de fontes de metal fez com que as estatuetas entregues durante a premiação fossem feitas de gesso. Anos depois, os Oscar foram substituídos pelas tradicionais peças metálicas.
</br></br>10º  Cada estatueta entregue na noite de gala tem um custo de fabricação de 500 dólares. Elas medem 34 centímetros e pesam pouco mais de três quilos. 2.809 Oscars já foram entregues desde 1929.
</p><h3>
</article>
</section>
<footer id="rodape">
include footer.inc;
 </footer>

</body>
</html>