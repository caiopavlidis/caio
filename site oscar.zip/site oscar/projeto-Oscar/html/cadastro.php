<!DOCTYPE html>
<html lang="pt-	br" id="macksocial">
<head>
<title>Oscar</title>
<meta charset="utf-8">
<link rel="stylesheet" href="..\\\css\estilo.css">
</head>
<body>
<form method="POST" name="form" id="cadastro">
<input type=hidden name="destino" value="#">
<label for="nome"><p><font size="5"><b>Nome Completo:</b></font></p></label>
<input class="borda" type="text" name="nome" size="45" maxlength="30" id="nome" placeholder=" Escreva seu nome completo" >

</br>
</br>
<label for="tia"><p><font size="5"><b>CPF:</b></font></p></label>
<input class="borda" type="text" name="cpf" id="cpf" size="45" maxlength="30" placeholder=" Escreva seu CPF">

</br>
</br>
<label for="email"><p><font size="5"><b>E-mail:</b></font></p></label>
<input class="borda" type="email" name="email" id="email" size="45" maxlength="30" placeholder=" Escreva seu email">

</br>
</br>
<label for="email"><p><font size="5"><b>E-mail:</b></font></p></label>
<input class="borda" type="email" name="email" id="email" size="45" maxlength="30" placeholder=" Confirme seu email">

</br>
</br>
<label for="datanascimento"><p><font size="5"><b>Data de nascimento:</b> </font></p></label>
<input type="date" name="datanascimento" id="datanascimento" size="20" /><br />
</br>
</br>
<label for="Estado"><p><font size="15"><b>Estado:</b> </font></p></label>
<input class="borda" type="email" name="email" id="email" size="45" maxlength="30" placeholder="Digite seu Estado">
</br>
</br>

<label for="Cidade"><p><font size="15"><b>Cidade:</b> </font></p></label>
<input class="borda" type="cidade" name="cidade" id="cidade" size="45" maxlength="30" placeholder="Digite sua Cidade">
</br>
</br>
<li><a href="#" style="text-decoration: none"><font color="black">Proximo>></a></li>

<footer id="rodape">
include footer.inc;
 </footer>

</body>

</html>