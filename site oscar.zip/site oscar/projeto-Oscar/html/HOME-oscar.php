<!DOCTYPE html>
<html lang="pt-	br">
<head>
<title>Oscar</title>
<meta charset="utf-8">
<link rel="stylesheet" href="..\\\css\estilo.css">
</head>
<body>
<div id="site">

<header id="topo">
inclue header.inc;
</header></br>

<nav id="menu">
include 'menu.inc';
</nav>
<form method="post">
<div id="login">  <p><font size"5">Login: <input type="text" name="username" size="20">
<p><font size"5">Senha: <input type="password" name="senha" size="15">
<input type="submit" name="Mensagem2" value="ENTRAR" id="botaoentrar" onClick="enviado()"> </div> </p>
<li><a href="cadastro.php" style="text-decoration: none"><font color="gold">Cadastro</a></li>
<section id="conteudo">

<header>
<h1>Introdução<h1>
</header>
<article>
<p><h3>Tradicionalmente , filmes de guerra, musicais ou dramas históricos eram os gêneros de maior sucesso, mas durante a 
década de 2000 os maiores sucessos foi os de ''fantasia'', como Harry Potter, Piratas do Caribe, e O Senhor dos Anéis.</br></br>
Filmes ocupando as dez primeiras posições da lista que ainda não fazem parte de nenhuma franquia são Avatar (2009) e Titanic (1997), ambos dirigidos pelo canadense James Cameron, e Frozen.</br></br>
Outro gênero que recebeu grande interesse do público no último século foram as adaptações de super-heróis, como Batman e Superman da editora DC Comics e Homem-Aranha, X-Men, Homem de Ferro e Os Vingadores da editora Marvel. Os filmes de animação também obtiveram ótimos desempenhos, principalmente os produzidos digitalmente, como Toy Story, Procurando Nemo e Up - Altas Aventuras da premiada Pixar; Shrek e Madagascar da DreamWorks Animation, assim como A Era do Gelo da Blue Sky Studios.
</p><h3>
</article>
</section>
<footer id="rodape">
include footer.inc;
 </footer>
</body>
</html>