<!DOCTYPE html>
<html lang="pt-	br">
<head>
<title>Melhores Atrizes</title>
<meta charset="utf-8">
<link rel="stylesheet" href="F:\Mackenzie\Tecnologia WEB I\projeto-Oscar\css\estiloMelhoresAtrizes.css">
</head>
<body>
<div id="site">

<header id="topo">
inclue header.inc;
</header></br>

<nav id="menu">
include 'menu.inc';
</nav>
<section id="conteudo">
<article>
<h3>
<table cellpadding="0" cellspacing="30">
<thead>
<tr>
<th><h2>ANO</h2></th>
<th><h2>FILME</h2></th>
<th><h2>ATRIZ</h2></th>
<th><h2>PERSONAGEM</h2></th>
</tr>
<tbody>

<tr>
<td>2001</td>
<td>Erin Brockovish - Uma Mulher de Talento</td>
<td>Julia Roberts</td>
<td>Erin Brockovish</td>
</tr>
<tr>
<td>2002</td>
<td>A Última Ceia</td>
<td>Haller Berry</td>
<td>Leticia Musgrove</td>
</tr>
<tr>
<td>2003</td>
<td>As Horas</td>
<td>Nicole Kidman</td>
<td>Virginia Woolf</td>
</tr>
<tr>
<td>2004</td>
<td>Monster - Desejo Assassino</td>
<td>Charlize Theron</td>
<td>Aileen Wuornos</td>
</tr>
<tr>
<td>2005</td>
<td>Menina de Ouro</td>
<td>Hilary Swank</td>
<td>Maggie Fitzgerald</td>
</tr>
<tr>
<td>2006</td>
<td>Johnny e June</td>
<td>Reese Witherspoon</td>
<td>June Carter</td>
</tr>
<tr>
<td>2007</td>
<td>A Rainha</td>
<td>Helen Mirren</td>
<td>Rainha Isabel II</td>
</tr>
<tr>
<td>2008</td>
<td>Piaf - Um Hino ao Amor</td>
<td>Marion Cotillard</td>
<td>Edith Piaf</td>
</tr>
<tr>
<td>2009</td>
<td>O Leitor</td>
<td>Kate Winslet</td>
<td>Hanna Schmitz</td>
</tr>
<tr>
<td>2010</td>
<td>Um Sonho Possível</td>
<td>Sandra Bullock</td>
<td>Leigh Anne Tuohy</td>
</tr>
<tr>
<td>2011</td>
<td>Cisne Negro</td>
<td>Natalie Portman</td>
<td>Nina Sayers</td>
</tr>
<tr>
<td>2012</td>
<td>A Dama de Ferro</td>
<td>Maryl Streep</td>
<td>Margaret Thatcher</td>
</tr>
<tr>
<td>2013</td>
<td>O Lado Bom da Vida</td>
<td>Jennifer Lawrence</td>
<td>Tiffany Maxwell</td>
</tr>
<tr>
<td>2014</td>
<td>Blue Jasmine</td>
<td>Cate Blanchett</td>
<td>Jeanette "Jasmine" Francis</td>
</tr>
</tbody>

</p><h3>
</article>
</section>
<footer id="rodape">
include footer.inc;
 </footer>

</body>
</html>