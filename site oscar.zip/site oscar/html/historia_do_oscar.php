<!DOCTYPE html>
<html lang="pt-	br">
<head>
<title>Historia do Oscar </title>
<meta charset="utf-8">
<link rel="stylesheet" href="css\estilo.css">
<link rel="stylesheet" href="css\galeria_min.css">
<link rel="stylesheet" href="css\galeria_tema.css">
</head>
<body>
<div id="site">

<?php
include "header.inc";
?>
<?php
include "menu.inc";
?>

<section id="conteudo">
<header>
<h1>História<h1>
</header>
<article>
<p><h3>Academia de Artes e Ciências Cinematográficas de Hollywood foi criada no dia 11 de janeiro de 1927. A idéia foi do presidente da Metro-Goldwin Mayer, Louis B. Mayer que uniu-se a um grupo de 36 diretores e atores para criar a Academia de Artes e Ciências Cinematográficas. Na época, os dirigentes dos grandes estúdios de cinema já vinham pensando em uma forma de incentivar a produção de obras de qualidade técnica e artística e a sugestão de Louis B. Mayer, foi acolhida com entusiasmo por todos.
</br></br>
A primeira entrega de prêmios foi realizada em maio de 1929, no Hotel Roosevelt de Los Angeles, sob a presidência do astro Douglas Fairbanks. Inicialmente, as cerimônias eram realizadas com almoços ou jantares em hotéis ou grandes restaurantes, com os resultados previamente conhecidos, já que a decisão sobre os ganhadores era tomada de comum acordo pelos chefões dos estúdios.  Até 1940 os jornais recebiam a lista de premiados antecipadamente e assumiam o compromisso de só divulgá-la no final da noite. Um ano amtes o Los Angeles Times quebrou o acordo. Desde então, a Academia decidiu manter segredo até a abertura dos envelopes lacrados.
</br></br>
 O critério de seleção é demorado e envolve cerca de mais ou menos 4.755 pessoas que tem direito a voto. Todos são profissionais do ramo: atores e atrizes, produtores, diretores, roteiristas, cenógrafos, montadores, fotógrafos, músicos, maquiadores. A Price Waterhouse, empresa de consultoria e estatística, organiza a votação na qual cada integrante da Academia vota em candidatos de sua mesma especialidade (fotógrafos votam em fotógrafos, atores em atores, etc.), mas todos elegem o Melhor Filme. Em uma segunda fase, a firma seleciona os cinco mais votados em cada categoria e é feita nova votação, desta vez com todos os membros da Academia. O sigilo é absoluto e jamais se soube de algum caso de quebra de segredo.
</br></br>
As cédulas são enviadas pelo correio e devolvidas à Academia em envelopes sem identifição do remetente. Já a apuração é feita por computador e colocada em envelopes lacrados, que são abertos apenas na noite da entrega do Oscar. Nem a Academia sabe de quantas estatuetas vai precisar.
</br></br>
A simples indicação de um filme pode aumentar sua bilheteria em vários milhões de dólares. Além do aumento da receita, a premiação significa prestígio para o filme, contratos mais vantajosos para os atores e (quase sempre) uma garantia de qualidade para o público.
</br></br></br>
</p><h3>
</article>
</section>
<?php
include "footer.inc";
?>

</body>
</html>