<!DOCTYPE html>
<html lang="pt-	br">
<head>
<title>Melhores Atores </title>
<meta charset="utf-8">
<link rel="stylesheet" href="css\estilo.css">
<link rel="stylesheet" href="css\galeria_min.css">
<link rel="stylesheet" href="css\galeria_tema.css">
</head>
<body>
<div id="site">

<?php
include "header.inc";
?>
<?php
include "menu.inc";
?>

<section id="conteudo">
<article>
<h3>
<table cellspacing="30">
<thead>
<tr>
<th><h2>ANO</h2></th>
<th><h2>FILME</h2></th>
<th><h2>ATOR</h2></th>
<th><h2>PERSONAGEM</h2></th>
</tr>
<tbody>

<tr>
<td>2001</td>
<td>Gladiador</td>
<td>Russell Crowe</td>
<td>Máximo Décimo Meridius</td>
</tr>
<tr>
<td>2002</td>
<td>Dia de Treinamento</td>
<td>Denzel Washington</td>
<td>Alonzo Harris</td>
</tr>
<tr>
<td>2003</td>
<td>O Pianista</td>
<td>Adrien Brody</td>
<td>Wladyslaw Szpilman</td>
</tr>
<tr>
<td>2004</td>
<td>Sobre Meninos e Lobos </td>
<td>Sean Penn</td>
<td>Jimmy Markum</td>
</tr>
<tr>
<td>2005</td>
<td>Ray</td>
<td>Jamie Foxx</td>
<td>Ray Charles</td>
</tr>
<tr>
<td>2006</td>
<td>Capote</td>
<td>Philip Seymour Hoffman</td>
<td>Truman Capote</td>
</tr>
<tr>
<td>2007</td>
<td>O Último Rei da Escócia</td>
<td>Forrest Whitaker</td>
<td>Presidente Idi Amin</td>
</tr>
<tr>
<td>2008</td>
<td>Sangue Negro</td>
<td>Daniel Day-Lewis</td>
<td>Daniel Plainview</td>
</tr>
<tr>
<td>2009</td>
<td>Milk: A Voz da Igualdade</td>
<td>Sean Penn</td>
<td>Harvey Milk</td>
</tr>
<tr>
<td>2010</td>
<td>Coração Louco</td>
<td>Jeff Bridges</td>
<td>Otis "Bad" Blake</td>
</tr>
<tr>
<td>2011</td>
<td>O Discurso do Rei</td>
<td>Colin Firth</td>
<td>Rei Jorge VI do Reino Unido</td>
</tr>
<tr>
<td>2012</td>
<td>O Artista</td>
<td>Jean Dujardin</td>
<td>George Valentin</td>
</tr>
<tr>
<td>2013</td>
<td>Lincoln</td>
<td>Daniel Day-Lewis</td>
<td>Presidente Abraham Lincoln</td>
</tr>
<tr>
<td>2014</td>
<td>Clube de Compras Dallas</td>
<td>Matthew McConaughey</td>
<td>Ron Woodroof</td>
</tr>
</tbody>


</p><h3>
</article>
</section>
</br></br></br>
<?php
include "footer.inc";
?>


</body>
</html>