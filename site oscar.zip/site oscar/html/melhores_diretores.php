<!DOCTYPE html>
<html lang="pt-	br">
<head>
<title>Melhores Diretores </title>
<meta charset="utf-8">
<link rel="stylesheet" href="css\estilo.css">
<link rel="stylesheet" href="css\galeria_min.css">
<link rel="stylesheet" href="css\galeria_tema.css">
</head>
<body>
<div id="site">

<?php
include "header.inc";
?>
<?php
include "menu.inc";
?>

<section id="conteudo">
<header>
<h1>Melhores Diretores <h1>
</header>
<article>
<p><h3>
<table cellpadding="0" cellspacing="30">
<thead>
<tr>
<th>ANO</th>
<th>FILME</th>
<th>DIRETOR</th>
</tr>
<tbody>

<tr>
<td>2001</td>
<td>Tráfico</td>
<td>Steven Soderbergh</td>
</tr>
<tr>
<td>2002</td>
<td>Uma Mente Brilhante</td>
<td>Ron Howard</td>
</tr>
<tr>
<td>2003</td>
<td>O Pianista</td>
<td>Roman Polanski</td>
</tr>
<tr>
<td>2004</td>
<td>Senhor dos Anéis - O Retorno do Rei</td>
<td>Peter Jackson</td>
</tr>
<tr>
<td>2005</td>
<td>Menina de Ouro</td>
<td>Clint Eastwood</td>
</tr>
<tr>
<td>2006</td>
<td>O Segredo de Brokeback Montain</td>
<td>Ang Lee</td>
</tr>
<tr>
<td>2007</td>
<td>Os Infiltrados</td>
<td>Martin Scorsese</td>
</tr>
<tr>
<td>2008</td>
<td>Onde os Fracos Não Têm Vez</td>
<td>Joel Coen e Ethan Coen</td>
</tr>
<tr>
<td>2009</td>
<td>Quem Quer Ser Um Milionário?</td>
<td>Danny Boyle</td>
</tr>
<tr>
<td>2010</td>
<td>Guerra ao Terror</td>
<td>Kathryn Bigelow</td>
</tr>
<tr>
<td>2011</td>
<td>O Discurso do Rei</td>
<td>Tom Hooper</td>
</tr>
<tr>
<td>2012</td>
<td>O Artista</td>
<td>Michel Hazanavicius</td>
</tr>
<tr>
<td>2013</td>
<td>As Aventuras de Pi</td>
<td>Ang Lee</td>
</tr>
<tr>
<td>2014</td>
<td>Gravidade</td>
<td>Alfonso Cuarón</td>
</tr>
</tbody>

</p><h3>
</article>
</section>

<?php
include "footer.inc";
?>

</body>
</html>