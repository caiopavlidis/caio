<!DOCTYPE html>
<html lang="pt-	br">
<head>
<title>Contato</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css\estiloContato.css">

<script >
function verificarTexto() {
if (form.texto.value == "")
{alert ("Não há texto escrito") }
}
function verificarTexto2() {
if (form.email.value == "")
{alert ("Não há texto escrito") }
var filtro_mail = /^.+@.+\..{2,3}$/
if (!filtro_mail.test(form.email.value) || form.email.value=="") {
alert("Preencha o e-mail corretamente.");
form.email.focus();
return false;
}
}
function verificarTexto3() {
if (form.assunto.value == "")
{alert ("Não há texto escrito") }
}
function verificarTexto4() {
if (form.Mensagem.value == "")
{alert ("Não há texto escrito") }
}
function enviado() {
alert ("Mensagem enviada com sucesso!")
}

</script>
    
<title>Contato </title>
<meta charset="utf-8">
<link rel="stylesheet" href="css\estilo.css">
<link rel="stylesheet" href="css\galeria_min.css">
<link rel="stylesheet" href="css\galeria_tema.css">


</head>


<body>

<div id="site">

<?php
include "header.inc";
?>
<?php
include "menu.inc";
?>


<form name="form" id="contato">
<input type=hidden name="destino" value="matheus-brienza@hotmail.com">

<h3>Digite seu nome:</h3>
<input type=text name="texto" size="45">
<input type=button value="Verificar" onClick="verificarTexto()">
</br>
</br>
<h3>Digite seu e-mail:</h3>
<input type=text name="email" size="45">
<input type=button value="Verificar" onClick="verificarTexto2()">
</br>
</br>
<h3>Assunto:</h3>
<input type=text name="assunto" size="45">
<input type=button value="Verificar" onClick="verificarTexto3()">
</br>
</br>
<h3>Mensagem:</h3></br>
<textarea name="Mensagem" rows="10" cols="60" wrap="virtual"></textarea>
<input type=button value="Verificar" onClick="verificarTexto4()"></br>

<input type="submit" name="Mensagem2" value="Enviar Mensagem" onClick="enviado()"> 
<input type="reset" value="Limpar Formulário">
<br>
<br>
<br>
<a href="index.html" ><font color="black"><h3> VOLTAR À HOME </h3></font></a>
</form>
<?php
include "footer.inc";
?>

</body>

</html>