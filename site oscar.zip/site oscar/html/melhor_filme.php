<!DOCTYPE html>
<html lang="pt-	br">
<head>
<title>Melhor Filme </title>
<meta charset="utf-8">
<link rel="stylesheet" href="css\estilo.css">
<link rel="stylesheet" href="css\galeria_min.css">
<link rel="stylesheet" href="css\galeria_tema.css">
</head>
<body>
<div id="site">
<?php
include "header.inc";
?>
<?php
include "menu.inc";
?>
<section id="conteudo">
<header>
<h1>Melhores Filmes<h1>
</header>
<article>
<p><h3>
<table cellpadding="0" cellspacing="30">
<thead>
<tr>
<th>ANO</th>
<th>FILME</th>
</tr>
<tbody>

<tr>
<td>2001</td>
<td>Gladiador</td>
</tr>
<tr>
<td>2002</td>
<td>Uma Mente Brilhante</td>
</tr>
<tr>
<td>2003</td>
<td>Chicago</td>
</tr>
<tr>
<td>2004</td>
<td>Senhor dos Anéis - O Retorno do Rei</td>
</tr>
<tr>
<td>2005</td>
<td>Menina de Ouro</td>
</tr>
<tr>
<td>2006</td>
<td>Crash - No Limite</td>
</tr>
<tr>
<td>2007</td>
<td>Os Infiltrados</td>
</tr>
<tr>
<td>2008</td>
<td>Onde os Fracos Não Têm Vez</td>
</tr>
<tr>
<td>2009</td>
<td>Quem Quer Ser Um Milionário?</td>
</tr>
<tr>
<td>2010</td>
<td>Guerra ao Terror</td>
</tr>
<tr>
<td>2011</td>
<td>O Discurso do Rei</td>
</tr>
<tr>
<td>2012</td>
<td>O Artista</td>
</tr>
<tr>
<td>2013</td>
<td>Argo</td>
</tr>
<tr>
<td>2014</td>
<td>12 Anos de Escravidão</td>
</tr>
</tbody>

</p><h3>
</article>
</section>

<?php
include "footer.inc";
?>
</body>
</html>