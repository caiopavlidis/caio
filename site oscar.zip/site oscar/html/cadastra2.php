<!DOCTYPE html>
<html lang="pt-	br" id="macksocial">
<head>
<title>Oscar</title>
<meta charset="utf-8">
<link rel="stylesheet" href="..\\\css\estilo.css">
</head>
<body>
<form method="POST" name="form" id="cadastro">
<input type=hidden name="destino" value="#">
<label for="nome"><p><font size="5"><b>Username:</b></font></p></label>
<input class="borda" type="text" name="username" size="45" maxlength="30" id="username" placeholder=" Escreva seu Username" >

</br>
</br>
<label for="nome"><p><font size="5"><b>Senha:</b></font></p></label>
<input class="borda" type="text" name="senha" size="45" maxlength="30" id="senha" placeholder=" Escreva seu Senha" >

</br>
</br>
<label for="nome"><p><font size="5"><b>Cofirme a senha:</b></font></p></label>
<input class="borda" type="text" name="senha" size="45" maxlength="30" id="senha" placeholder=" Confirme sua Senha" >

</br>
</br>
<p><font size="5"><b>Li e concordo com o regulamento</b></font></p>
<input type="checkbox" value="accept" id="concordo">
</br>
</br>
<li><a href="#" style="text-decoration: none"><font color="black">Cadastrar</a></li>
</form>
</body>
</html>
